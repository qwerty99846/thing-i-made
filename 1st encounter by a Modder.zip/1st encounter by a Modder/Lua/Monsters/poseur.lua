-- A basic monster script skeleton you can copy and modify for your own creations.
comments = {"Smells like the work\rof an enemy stand.", "Gamer likes to\rgame like his\rlife depends on it.", "Gamer's limbs shouldn't move\rthat way."}
commands = {"Threaten", "Flirt", "Kind"}
randomdialogue = {"Do you\nlike my\nattacks.", "I like\ngaming.", "This is\nnot fun."}

sprite = "Gamer" --Always PNG. Extension is added automatically.
name = "Gamer"
hp = 150
atk = 3
def = 5
check = "He's games so hard."
dialogbubble = "right" -- See documentation for what bubbles you have available.
canspare = true
cancheck = true

-- Happens after the slash animation but before 
function HandleAttack(attackstatus)
    if attackstatus == -1 then
        -- player pressed fight but didn't press Z afterwards
    else
        -- player did actually attack
    end
end
 
-- This handles the commands; all-caps versions of the commands list you have above.
function HandleCustomCommand(command)
    if command == "THREATEN" then
        currentdialogue = {"So who\ncares if\nyou Thr-\neaten."}
    elseif command == "FLIRT" then
        currentdialogue = {"No\nthanks\n i dont\ncare for\nFlirting."}
    elseif command == "KIND" then
        currentdialogue = {"Awww\nthanks\nfor\nbeing\nKind."}
    end
    BattleDialog({"You selected " .. command .. "."})
end
-- help i did something wrong and i dont know what
-- i found out
-- The text box it too small