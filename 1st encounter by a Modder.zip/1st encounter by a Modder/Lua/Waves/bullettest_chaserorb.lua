-- The chasing attack from the documentation example.
chasingbullet = CreateProjectile('bullet', Arena.width/2, Arena.height/2)
chasingbullet.SetVar('xspeed', 0)
chasingbullet.SetVar('yspeed', 0)

function Update()
    local xdifference = Player.x - chasingbullet.x
    local ydifference = Player.y - chasingbullet.y
    local xspeed = chasingbullet.GetVar('xspeed') / 50 + xdifference / 20
    local yspeed = chasingbullet.GetVar('yspeed') / 50 + ydifference / 20
    chasingbullet.Move(xspeed, yspeed)
    chasingbullet.SetVar('xspeed', xspeed)
    chasingbullet.SetVar('yspeed', yspeed)
end
-- Modder here i still havent learned lua but i think i can still make this attack more harmful i
-- just incressed the speed a bit Modder out
-- log 2  So im calling these "logs" now, anyway that did work but im incressing the speed more
-- from 3 to 5  log end
-- log 3  still not dangrus enofe so im incressing from 5 to 10 also decressing the 100 to 90
-- maybe this time it will do what i want  log end
-- log 4  MORE  log end
-- log 5  I think that this attack was made to be easy  log end
-- log 6  still easy  log end
-- log 7  bruh  log end
-- log 8  bruh2  log end
-- log 9  finaly now i will work on outhers (yes i know i spell bad)  log end
-- log 10  i was wrong too hard so im turning down the speed  log end